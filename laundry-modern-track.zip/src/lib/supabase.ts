import { createClient } from '@supabase/supabase-js';


// Initialize database client
const supabaseUrl = 'https://kegbafokuldyslsewkdv.databasepad.com';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ijk1MzgzMzQwLWJjNTItNDFkYy1hZmY5LWQzZWFhMTlmYTA1NyJ9.eyJwcm9qZWN0SWQiOiJrZWdiYWZva3VsZHlzbHNld2tkdiIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzc4OTMxNjgyLCJleHAiOjIwOTQyOTE2ODIsImlzcyI6ImZhbW91cy5kYXRhYmFzZXBhZCIsImF1ZCI6ImZhbW91cy5jbGllbnRzIn0.zQ_JzhhzIWvS4j5TX7-zUSyfn4eQpae7NNytWqWN8Ho';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };